# My ITOL Vault

A responsive three-page diary built with HTML, CSS and vanilla JavaScript.

![Homepage showing five sample entries](docs/screenshot.jpg)

## Run locally

From this folder run `python3 -m http.server 8000 --directory dist`, then open http://localhost:8000. Use the same browser and address to access your saved entries.

## Pages

- `dist/index.html`: the five most recent reflections in a responsive grid.
- `dist/new-entry.html`: a labelled form with title, reflection and optional comma-separated tags.
- `dist/vault.html`: every saved entry, newest first, in full-width rows.
- `dist/styles.css`: shared styling and a single-column layout for small screens.
- `dist/app.js`: form events, browser storage and DOM rendering.

## How it works

The form's submit listener prevents the default submission and reads the input values using DOM selectors. Empty and whitespace-only entries are rejected. The entry is added to an array with its creation timestamp. `JSON.stringify()` converts this array to text before `localStorage.setItem('entries', ...)` saves it.

Each listing uses `JSON.parse()` to retrieve the array from the `entries` key. Entries are sorted by creation time, newest first. The homepage uses `entries.slice(0, 5)` to produce a separate array containing only the latest five; the vault renders the complete array. Standard anchor links connect the pages. Cards are created with DOM methods and `textContent`, so typed HTML is displayed as text.

Storage reference: https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage

Entries remain in this browser on this site until browser storage is cleared. They do not synchronize between devices or addresses. This is a browser diary, without account authentication or encryption. Unreadable storage and failed saves display a message without silently replacing existing data.

## Validation performed

Saved six entries through the UI; checked that the homepage contains five and the vault contains six, in newest-first order. Reloaded the page to verify persistence. Entered HTML-like text and verified it was displayed literally. JavaScript syntax checked with `node --check dist/app.js`. The screenshot contains demonstration data only; a new browser starts empty.

## Submission

Upload this project to your own GitHub repository and submit that repository link according to the assignment brief. This package does not include a fabricated development history. Continue to commit meaningful changes as you review and personalize the work. Read and understand the code before submitting it.
